package com.example.unionpplication;

import androidx.lifecycle.ViewModel;

public class ForthViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}