package com.example.unionpplication;

import androidx.lifecycle.ViewModel;

public class SecondViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}