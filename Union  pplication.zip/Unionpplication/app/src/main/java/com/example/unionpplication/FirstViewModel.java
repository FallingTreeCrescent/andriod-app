package com.example.unionpplication;

import androidx.lifecycle.ViewModel;

public class FirstViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}