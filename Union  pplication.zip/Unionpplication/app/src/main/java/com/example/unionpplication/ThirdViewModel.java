package com.example.unionpplication;

import androidx.lifecycle.ViewModel;

public class ThirdViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}